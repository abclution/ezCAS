#!/usr/bin/env python3

from pathlib import Path
import ast


def extract_raw_function_slices(source_code: str) -> dict[str, str]:
    tree = ast.parse(source_code)
    lines = source_code.splitlines(keepends=True)
    extracted = {}

    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            start_line = node.lineno - 1
            end_line = node.end_lineno
            extracted[node.name] = "".join(lines[start_line:end_line])

    return extracted


def export_functions(source_path: Path, output_dir: Path) -> None:
    source_code = source_path.read_text(encoding="utf-8")
    functions = extract_raw_function_slices(source_code)

    target_dir = output_dir / source_path.stem
    target_dir.mkdir(parents=True, exist_ok=True)

    for name, code in functions.items():
        out_file = target_dir / f"{name}.py"
        out_file.write_text(code.rstrip() + "\n", encoding="utf-8")


if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1:
        src = Path(sys.argv[1])
        dst = Path(sys.argv[2]) if len(sys.argv) > 2 else Path("./extracted_fns")
        export_functions(src, dst)
