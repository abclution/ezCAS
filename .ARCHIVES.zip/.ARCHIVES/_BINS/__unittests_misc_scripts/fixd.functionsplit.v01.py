#!/usr/bin/env python3

from pathlib import Path
import ast


def extract_top_level_nodes(source_code: str):
    tree = ast.parse(source_code)
    imports, constants, functions, others = [], [], [], []

    for node in tree.body:
        if isinstance(node, (ast.Import, ast.ImportFrom)):
            imports.append(node)
        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            functions.append(node)
        elif isinstance(node, ast.Assign) and all(
            isinstance(t, ast.Name) and t.id.isupper() for t in node.targets
        ):
            constants.append(node)
        else:
            others.append(node)
    return imports, constants, functions, others


def build_module_content(imports: list, constants: list, func_node: ast.AST) -> str:
    module_tree = ast.Module(
        body=[*imports, *constants, func_node],
        type_ignores=[]
    )
    return ast.unparse(module_tree)


def build_entry_content(
    pkg_name: str,
    imports: list,
    constants: list,
    funcs: list,
    remaining_nodes: list
) -> str:
    func_imports = [
        ast.ImportFrom(
            module=f"{pkg_name}.{f.name}",
            names=[ast.alias(name=f.name, asname=None)],
            level=0
        )
        for f in funcs
    ]
    entry_tree = ast.Module(
        body=[*imports, *func_imports, *constants, *remaining_nodes],
        type_ignores=[]
    )
    return ast.unparse(entry_tree)


def split_script(source_path: Path, output_dir: Path) -> None:
    source_code = source_path.read_text(encoding="utf-8")
    imports, constants, funcs, others = extract_top_level_nodes(source_code)

    if not funcs:
        return

    pkg_dir = output_dir / f"{source_path.stem}_modules"
    pkg_dir.mkdir(parents=True, exist_ok=True)
    (pkg_dir / "__init__.py").touch()

    for func in funcs:
        func_file = pkg_dir / f"{func.name}.py"
        func_code = build_module_content(imports, constants, func)
        func_file.write_text(func_code + "\n", encoding="utf-8")

    main_code = build_entry_content(
        pkg_dir.name, imports, constants, funcs, others
    )
    (output_dir / source_path.name).write_text(main_code + "\n", encoding="utf-8")


if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1:
        target = Path(sys.argv[1])
        dest = Path(sys.argv[2]) if len(sys.argv) > 2 else Path("./output")
        split_script(target, dest)
