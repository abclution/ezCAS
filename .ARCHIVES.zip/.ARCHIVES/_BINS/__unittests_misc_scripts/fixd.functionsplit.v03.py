#!/usr/bin/env python3

from pathlib import Path
import ast


def get_node_start_line(node: ast.AST) -> int:
    if getattr(node, "decorator_list", None):
        return node.decorator_list[0].lineno - 1
    return node.lineno - 1


def extract_slice(lines: list[str], node: ast.AST) -> str:
    start = get_node_start_line(node)
    end = node.end_lineno
    return "".join(lines[start:end]).rstrip() + "\n"


def parse_and_export_components(source_path: Path, output_dir: Path) -> None:
    source_code = source_path.read_text(encoding="utf-8")
    lines = source_code.splitlines(keepends=True)
    tree = ast.parse(source_code)

    base_dir = output_dir / source_path.stem
    base_dir.mkdir(parents=True, exist_ok=True)

    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            file_path = base_dir / f"{node.name}.py"
            file_path.write_text(
                extract_slice(lines, node), encoding="utf-8"
            )

        elif isinstance(node, ast.ClassDef):
            class_dir = base_dir / node.name
            class_dir.mkdir(parents=True, exist_ok=True)

            for item in node.body:
                if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    method_path = class_dir / f"{item.name}.py"
                    method_path.write_text(
                        extract_slice(lines, item), encoding="utf-8"
                    )


if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1:
        src = Path(sys.argv[1])
        dst = Path(sys.argv[2]) if len(sys.argv) > 2 else Path("./extracted")
        parse_and_export_components(src, dst)
